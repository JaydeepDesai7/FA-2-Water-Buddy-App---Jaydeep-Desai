# WaterBuddy

A responsive, browser-based hydration companion prototype.

## Run it
1. Download and unzip `WaterBuddy.zip`.
2. Open `index.html` in a modern browser (Chrome, Safari, Edge, or Firefox).
3. On first launch, choose an age group, select an example daily goal, and choose an experience mode.

No installation, account, internet connection, or external dependencies are required.

## Included
- Age-group onboarding and adjustable example goal
- Dashboard, progress ring, quick-add buttons, and custom water logging
- Timestamped water log with removal controls
- Milestones, mascot feedback, buddy selection, themes, missions, and adventure unlocks
- Daily summaries and confirmation-based new-day reset
- Historical progress from locally saved records
- Kids, teen, and minimal modes; dark/light appearance; reduced motion
- JSON data export and local data reset

## Data and limitations
The app stores data in browser local storage on the current device/browser. Clearing browser data may remove it; use Export my data for a backup. Notifications and cloud sync are not implemented. Daily goals are example targets and are not medical advice. The app is a functional prototype, not a medical device.

## Project structure
- `index.html` — complete UI, styles, and application logic in one file.
